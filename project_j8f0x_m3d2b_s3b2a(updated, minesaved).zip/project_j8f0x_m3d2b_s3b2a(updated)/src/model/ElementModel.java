package model;

public class ElementModel {
    String name;

    public ElementModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
