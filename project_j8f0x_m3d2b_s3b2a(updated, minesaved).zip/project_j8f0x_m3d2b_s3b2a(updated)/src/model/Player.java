package model;

public class Player {
    private final String username;
    private final String email;
    private final String password;
    private final String displayName;

    public Player(String username, String email, String password, String displayName) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.displayName = displayName;
    }

    // getters
    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void consumes(Food food, int amount){}

}
